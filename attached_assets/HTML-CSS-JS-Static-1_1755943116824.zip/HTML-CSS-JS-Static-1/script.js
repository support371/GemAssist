
// ATR & GEM Templates Collection - Interactive Features

document.addEventListener('DOMContentLoaded', function() {
    // Add smooth scrolling for internal links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Add click handlers for template buttons
    document.querySelectorAll('.btn-template').forEach(button => {
        button.addEventListener('click', function() {
            const buttonText = this.textContent.trim();
            
            switch(buttonText) {
                case '🏛️ Federal Authorization':
                    handleFederalAuthorization();
                    break;
                case '⚡ Express Processing':
                    handleExpressProcessing();
                    break;
                case '📞 Immediate Call':
                    handleImmediateCall();
                    break;
                case '🏛️ Federal Review':
                    handleFederalReview();
                    break;
                case '📋 Download Report':
                    handleDownloadReport();
                    break;
                case '📧 Email Copy':
                    handleEmailCopy();
                    break;
                default:
                    console.log('Button clicked:', buttonText);
            }
        });
    });

    // Add form field interaction enhancements
    document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            updateCheckboxStatus(this);
        });
    });

    // Add print functionality
    addPrintButtons();
    
    // Initialize form auto-save (basic implementation)
    initAutoSave();
});

// Button handler functions
function handleFederalAuthorization() {
    showNotification('🏛️ Federal Authorization process initiated. Bernard Gilbert has been notified.', 'success');
    // Trigger live signal update
    updateSignalStatus('federal', 'alert', 'AUTHORIZATION LIVE');
    setTimeout(() => {
        updateSignalStatus('federal', 'active', 'GILBERT CONFIRMED');
    }, 3000);
}

function handleExpressProcessing() {
    showNotification('⚡ Express processing activated. 24-hour response guarantee in effect.', 'info');
    // Activate emergency monitoring
    updateSignalStatus('emergency', 'alert', 'EXPRESS ACTIVE');
    updateSignalStatus('treasury', 'alert', 'PRIORITY QUEUE');
}

function handleImmediateCall() {
    showNotification('📞 Connecting to Federal Emergency Hotline: (203) 555-0124', 'info');
    // Signal emergency channel activation
    updateSignalStatus('emergency', 'alert', 'HOTLINE ACTIVE');
    // In a real implementation, this might open a phone dialer or VoIP application
}

function handleFederalReview() {
    showNotification('🏛️ Case submitted for Federal Review. Multi-agency coordination initiated.', 'success');
}

function handleDownloadReport() {
    showNotification('📋 Report download prepared. Federal compliance verified.', 'success');
    // In a real implementation, this would trigger a PDF download
}

function handleEmailCopy() {
    showNotification('📧 Email copy sent to registered contact. Check your inbox.', 'success');
}

// Utility functions
function updateCheckboxStatus(checkbox) {
    const checkboxItem = checkbox.closest('.checkbox-item');
    if (checkboxItem) {
        if (checkbox.checked) {
            checkboxItem.style.backgroundColor = '#e6f7ff';
            checkboxItem.style.borderLeft = '4px solid var(--cyber-gold)';
        } else {
            checkboxItem.style.backgroundColor = 'var(--light-gray)';
            checkboxItem.style.borderLeft = 'none';
        }
    }
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span>${message}</span>
            <button class="notification-close">&times;</button>
        </div>
    `;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
        color: white;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 1000;
        max-width: 400px;
        animation: slideIn 0.3s ease;
    `;
    
    // Add animation styles to head if not already present
    if (!document.querySelector('#notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            .notification-content {
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            .notification-close {
                background: none;
                border: none;
                color: white;
                font-size: 18px;
                cursor: pointer;
                margin-left: 10px;
            }
        `;
        document.head.appendChild(style);
    }
    
    // Add to page
    document.body.appendChild(notification);
    
    // Add close functionality
    const closeBtn = notification.querySelector('.notification-close');
    closeBtn.addEventListener('click', () => {
        notification.remove();
    });
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

function addPrintButtons() {
    document.querySelectorAll('.template-card').forEach(card => {
        const printBtn = document.createElement('button');
        printBtn.className = 'btn-template';
        printBtn.innerHTML = '🖨️ Print Template';
        printBtn.style.marginTop = '15px';
        
        printBtn.addEventListener('click', function() {
            printTemplate(card);
        });
        
        card.appendChild(printBtn);
    });
}

function printTemplate(templateCard) {
    const templateName = templateCard.querySelector('.template-name').textContent;
    const printWindow = window.open('', '_blank');
    
    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>${templateName}</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                .form-field { margin: 15px 0; padding: 10px; border: 1px solid #ccc; }
                .signature-line { border-bottom: 2px solid #000; margin: 20px 0; height: 2px; }
                .federal-seal { background: #0b0b45; color: white; padding: 15px; text-align: center; margin: 10px 0; }
                .highlight-box { background: #C9A400; padding: 20px; margin: 15px 0; }
                @media print { body { margin: 0; } }
            </style>
        </head>
        <body>
            <h1>ATR & GEM CYBERSECURITY & MONITORING</h1>
            <h2>${templateName}</h2>
            ${templateCard.querySelector('.form-template').innerHTML}
        </body>
        </html>
    `);
    
    printWindow.document.close();
    printWindow.print();
}

function initAutoSave() {
    // Basic auto-save for form inputs (saves to localStorage)
    const formInputs = document.querySelectorAll('input[type="text"], input[type="email"], input[type="tel"], textarea');
    
    formInputs.forEach(input => {
        const saveKey = `atr_gem_${input.name || input.id || 'unknown'}`;
        
        // Load saved value
        const savedValue = localStorage.getItem(saveKey);
        if (savedValue && !input.value) {
            input.value = savedValue;
        }
        
        // Save on input
        input.addEventListener('input', function() {
            localStorage.setItem(saveKey, this.value);
        });
    });
}

// Add keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl+P for print
    if (e.ctrlKey && e.key === 'p') {
        e.preventDefault();
        window.print();
    }
    
    // Ctrl+S for save (show notification)
    if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        showNotification('💾 Template data auto-saved locally', 'success');
    }
});

// Add scroll progress indicator
function addScrollProgress() {
    const progressBar = document.createElement('div');
    progressBar.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 0%;
        height: 4px;
        background: linear-gradient(90deg, #0b0b45, #C9A400);
        z-index: 1001;
        transition: width 0.1s ease;
    `;
    document.body.appendChild(progressBar);
    
    window.addEventListener('scroll', () => {
        const scrollPercent = (window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100;
        progressBar.style.width = scrollPercent + '%';
    });
}

// Live Signal Monitoring System
function initLiveSignalMonitoring() {
    createMonitoringChatButton();
    startFederalMonitoring();
    startAssetTrackingSignals();
    startEmergencyChannelMonitoring();
}

function createMonitoringChatButton() {
    // Create chat button
    const chatButton = document.createElement('div');
    chatButton.id = 'monitoring-chat-button';
    chatButton.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 60px;
        height: 60px;
        background: linear-gradient(135deg, var(--royal-blue), var(--cyber-gold));
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 4px 15px rgba(11, 11, 69, 0.3);
        z-index: 1000;
        transition: all 0.3s ease;
        border: 3px solid rgba(255, 255, 255, 0.2);
    `;
    
    chatButton.innerHTML = `
        <div style="color: white; font-size: 24px; position: relative;">
            🛡️
            <div id="chat-signal-dot" style="position: absolute; top: -2px; right: -2px; width: 12px; height: 12px; background: #10b981; border-radius: 50%; animation: pulse 2s infinite; border: 2px solid white;"></div>
        </div>
    `;
    
    // Create chat panel (initially hidden)
    const chatPanel = document.createElement('div');
    chatPanel.id = 'monitoring-chat-panel';
    chatPanel.style.cssText = `
        position: fixed;
        bottom: 90px;
        right: 20px;
        width: 320px;
        height: 400px;
        background: rgba(11, 11, 69, 0.95);
        color: white;
        border-radius: 15px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.3);
        z-index: 999;
        backdrop-filter: blur(10px);
        border: 2px solid #C9A400;
        display: none;
        flex-direction: column;
    `;
    
    chatPanel.innerHTML = `
        <div style="padding: 15px; border-bottom: 1px solid rgba(201, 164, 0, 0.3); display: flex; justify-content: space-between; align-items: center;">
            <div style="display: flex; align-items: center;">
                <div id="main-signal" style="width: 10px; height: 10px; border-radius: 50%; background: #10b981; margin-right: 8px; animation: pulse 2s infinite;"></div>
                <strong>🛡️ Federal Monitoring</strong>
            </div>
            <button id="close-chat" style="background: none; border: none; color: white; font-size: 18px; cursor: pointer; opacity: 0.7; transition: opacity 0.3s;">&times;</button>
        </div>
        <div style="flex: 1; padding: 15px; overflow-y: auto;">
            <div id="signal-list">
                <div class="signal-item" data-signal="federal">
                    <span class="signal-dot"></span>
                    <span>Federal Oversight: </span>
                    <span class="signal-status">ACTIVE</span>
                </div>
                <div class="signal-item" data-signal="treasury">
                    <span class="signal-dot"></span>
                    <span>Treasury Coordination: </span>
                    <span class="signal-status">MONITORING</span>
                </div>
                <div class="signal-item" data-signal="emergency">
                    <span class="signal-dot"></span>
                    <span>Emergency Channel: </span>
                    <span class="signal-status">STANDBY</span>
                </div>
                <div class="signal-item" data-signal="asset">
                    <span class="signal-dot"></span>
                    <span>Asset Tracking: </span>
                    <span class="signal-status">SCANNING</span>
                </div>
            </div>
            <div style="margin-top: 15px; padding: 10px; background: rgba(201, 164, 0, 0.1); border-radius: 8px; font-size: 0.9em;">
                <div style="margin-bottom: 5px;">📞 Emergency Hotline:</div>
                <div style="color: #C9A400; font-weight: 600;">(203) 555-0124</div>
            </div>
        </div>
        <div style="padding: 10px 15px; border-top: 1px solid rgba(201, 164, 0, 0.3); font-size: 0.8em; color: #C9A400;">
            Last Update: <span id="last-update">--:--:--</span>
        </div>
    `;
    
    // Add chat styles
    const chatStyles = document.createElement('style');
    chatStyles.textContent = `
        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.5; }
            100% { opacity: 1; }
        }
        #monitoring-chat-button:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 20px rgba(11, 11, 69, 0.4);
        }
        #close-chat:hover {
            opacity: 1;
        }
        .signal-item {
            display: flex;
            align-items: center;
            margin: 8px 0;
            font-size: 0.85em;
            padding: 5px 0;
        }
        .signal-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            margin-right: 8px;
            background: #10b981;
            animation: pulse 2s infinite;
        }
        .signal-status {
            color: #C9A400;
            font-weight: 600;
            margin-left: auto;
            font-size: 0.9em;
        }
        .signal-item[data-status="alert"] .signal-dot {
            background: #ef4444;
            animation: pulse 1s infinite;
        }
        .signal-item[data-status="warning"] .signal-dot {
            background: #f59e0b;
        }
        .signal-item[data-status="alert"] .signal-status {
            color: #ef4444;
        }
    `;
    document.head.appendChild(chatStyles);
    
    // Add event listeners
    chatButton.addEventListener('click', () => {
        const panel = document.getElementById('monitoring-chat-panel');
        if (panel.style.display === 'none' || panel.style.display === '') {
            panel.style.display = 'flex';
            chatButton.style.transform = 'scale(0.9)';
        } else {
            panel.style.display = 'none';
            chatButton.style.transform = 'scale(1)';
        }
    });
    
    document.addEventListener('click', (e) => {
        if (e.target.id === 'close-chat') {
            document.getElementById('monitoring-chat-panel').style.display = 'none';
            chatButton.style.transform = 'scale(1)';
        }
    });
    
    // Close panel when clicking outside
    document.addEventListener('click', (e) => {
        const panel = document.getElementById('monitoring-chat-panel');
        const button = document.getElementById('monitoring-chat-button');
        if (!panel.contains(e.target) && !button.contains(e.target) && panel.style.display === 'flex') {
            panel.style.display = 'none';
            chatButton.style.transform = 'scale(1)';
        }
    });
    
    document.body.appendChild(chatButton);
    document.body.appendChild(chatPanel);
}

function updateSignalStatus(signalType, status, message) {
    const signalItem = document.querySelector(`[data-signal="${signalType}"]`);
    if (!signalItem) return;
    
    const signalStatus = signalItem.querySelector('.signal-status');
    
    signalItem.setAttribute('data-status', status);
    signalStatus.textContent = message;
    
    // Update timestamp
    const now = new Date();
    const updateElement = document.getElementById('last-update');
    if (updateElement) {
        updateElement.textContent = now.toLocaleTimeString();
    }
    
    // Update chat button indicator for alerts
    const chatSignalDot = document.getElementById('chat-signal-dot');
    if (chatSignalDot && status === 'alert') {
        chatSignalDot.style.background = '#ef4444';
        chatSignalDot.style.animation = 'pulse 1s infinite';
        
        // Reset to normal after 5 seconds
        setTimeout(() => {
            chatSignalDot.style.background = '#10b981';
            chatSignalDot.style.animation = 'pulse 2s infinite';
        }, 5000);
    }
    
    // Show notification for critical signals
    if (status === 'alert') {
        showNotification(`🚨 ${signalType.toUpperCase()}: ${message}`, 'error');
    }
}

function startFederalMonitoring() {
    // Simulate federal agency coordination signals
    setInterval(() => {
        const federalSignals = [
            { type: 'federal', status: 'active', message: 'Bernard Gilbert ONLINE' },
            { type: 'treasury', status: 'monitoring', message: 'FinCEN CONNECTED' },
            { type: 'federal', status: 'active', message: 'DHS COORDINATED' },
            { type: 'treasury', status: 'monitoring', message: 'AML SCANNING' }
        ];
        
        const randomSignal = federalSignals[Math.floor(Math.random() * federalSignals.length)];
        updateSignalStatus(randomSignal.type, randomSignal.status, randomSignal.message);
    }, 8000);
}

function startAssetTrackingSignals() {
    // Asset tracking simulation
    setInterval(() => {
        const assetSignals = [
            'BLOCKCHAIN SYNC',
            'GPS TRACKING',
            'DATABASE QUERY',
            'EXCHANGE MONITOR',
            'TITLE SEARCH'
        ];
        
        const randomAsset = assetSignals[Math.floor(Math.random() * assetSignals.length)];
        updateSignalStatus('asset', 'active', randomAsset);
    }, 12000);
}

function startEmergencyChannelMonitoring() {
    // Emergency channel monitoring
    setInterval(() => {
        const currentTime = new Date().getHours();
        
        if (currentTime >= 9 && currentTime <= 17) {
            updateSignalStatus('emergency', 'active', 'BUSINESS HOURS');
        } else {
            updateSignalStatus('emergency', 'warning', 'AFTER HOURS');
        }
        
        // Simulate occasional emergency alerts
        if (Math.random() < 0.05) { // 5% chance
            updateSignalStatus('emergency', 'alert', 'PRIORITY ALERT');
        }
    }, 15000);
}

// Initialize scroll progress
addScrollProgress();

// Initialize live signal monitoring
initLiveSignalMonitoring();
