
// Mobile Navigation Toggle
const navToggle = document.querySelector('.nav-toggle');
const navMenu = document.querySelector('.nav-menu');

navToggle.addEventListener('click', () => {
    navMenu.classList.toggle('active');
});

// Close mobile menu when clicking on a link
document.querySelectorAll('.nav-menu a').forEach(link => {
    link.addEventListener('click', () => {
        navMenu.classList.remove('active');
    });
});

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Navbar scroll effect
window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 100) {
        navbar.style.background = 'rgba(10, 14, 39, 0.98)';
        navbar.style.backdropFilter = 'blur(15px)';
    } else {
        navbar.style.background = 'rgba(10, 14, 39, 0.95)';
        navbar.style.backdropFilter = 'blur(10px)';
    }
});

// Bot-specific functions
function startBot() {
    // Simulate bot startup
    const btn = event.target;
    const originalText = btn.innerHTML;
    btn.innerHTML = '<span class="btn-icon">⚡</span>Initializing Bot...';
    btn.disabled = true;
    
    setTimeout(() => {
        alert('🤖 CyberWealth Bot is now active! You will receive a Telegram message to complete setup.');
        btn.innerHTML = originalText;
        btn.disabled = false;
        // In real implementation, this would redirect to Telegram or start bot process
        window.open('https://telegram.me/CyberWealthBot', '_blank');
    }, 2000);
}

function showDemo() {
    alert('🎬 Bot Demo: Our bots provide automated monitoring, instant alerts, and smart commands. Contact us for a live demonstration!');
}

function joinChannel(botType) {
    const channels = {
        'cyberwealth': 'https://telegram.me/CyberWealthBot',
        'wellness': 'https://telegram.me/WellnessSecurityBot',
        'realestate': 'https://telegram.me/RealEstateBot'
    };
    
    if (channels[botType]) {
        window.open(channels[botType], '_blank');
    }
}

function startTelegramBot() {
    window.open('https://telegram.me/CyberWealthBot', '_blank');
}

function viewBotCommands() {
    const commands = `
🤖 Available Bot Commands:

Security Bot:
/security_scan - Run full security analysis
/threat_check - Check for active threats
/vulnerability_scan - Scan for vulnerabilities

Asset Recovery Bot:
/asset_check - Monitor asset status
/recovery_status - Check recovery progress
/crypto_trace - Trace cryptocurrency transactions

Finance Monitor Bot:
/portfolio_status - Get portfolio overview
/market_alert - Set up market alerts
/price_watch - Monitor specific assets

Trading Signals Bot:
/signals - Get latest trading signals
/market_analysis - Deep market analysis
/risk_alert - Risk management alerts

Wallet Security Bot:
/wallet_scan - Scan wallet security
/transaction_monitor - Monitor transactions
/security_report - Get security report

Real Estate Bot:
/property_alert - Set property alerts
/market_data - Get market insights
/investment_tips - Receive investment advice
    `;
    
    alert(commands);
}

// Scroll animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observe elements for animation
document.querySelectorAll('.service-card, .stat-item, .feature-card, .pricing-card, .command-card').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(30px)';
    el.style.transition = 'all 0.6s ease';
    observer.observe(el);
});

// Contact form handling with bot service selection
const contactForm = document.querySelector('.contact-form');
if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Get form data
        const name = contactForm.querySelector('input[type="text"]').value;
        const email = contactForm.querySelector('input[type="email"]').value;
        const service = contactForm.querySelector('select').value;
        const message = contactForm.querySelector('textarea').value;
        
        // Simple validation
        if (!name || !email || service === 'Select Bot Service') {
            alert('Please fill in all required fields and select a bot service');
            return;
        }
        
        // Simulate form submission
        const submitBtn = contactForm.querySelector('.btn');
        const originalText = submitBtn.textContent;
        submitBtn.textContent = 'Requesting Bot Access...';
        submitBtn.disabled = true;
        
        setTimeout(() => {
            alert(`🤖 Bot Access Request Submitted!\n\nService: ${service}\n\nYou will receive setup instructions via Telegram within 24 hours. Please ensure you have Telegram installed and ready.`);
            contactForm.reset();
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }, 2500);
    });
}

// Enhanced button click effects for bot theme
document.querySelectorAll('.btn, .community-btn').forEach(btn => {
    btn.addEventListener('click', function(e) {
        // Create bot-themed ripple effect
        const ripple = document.createElement('span');
        const rect = this.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = e.clientX - rect.left - size / 2;
        const y = e.clientY - rect.top - size / 2;
        
        ripple.style.width = ripple.style.height = size + 'px';
        ripple.style.left = x + 'px';
        ripple.style.top = y + 'px';
        ripple.style.position = 'absolute';
        ripple.style.borderRadius = '50%';
        ripple.style.background = 'rgba(79, 209, 199, 0.4)';
        ripple.style.pointerEvents = 'none';
        ripple.style.animation = 'botRipple 0.8s ease-out';
        
        this.style.position = 'relative';
        this.style.overflow = 'hidden';
        this.appendChild(ripple);
        
        setTimeout(() => {
            ripple.remove();
        }, 800);
    });
});

// Add bot-themed ripple animation CSS
const style = document.createElement('style');
style.textContent = `
    @keyframes botRipple {
        0% {
            transform: scale(0);
            opacity: 1;
        }
        50% {
            opacity: 0.8;
        }
        100% {
            transform: scale(2.5);
            opacity: 0;
        }
    }
    
    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
    }
    
    .service-card:hover .service-icon {
        animation: pulse 1s infinite;
    }
`;
document.head.appendChild(style);

// Bot activity simulator
function simulateBotActivity() {
    const activities = [
        '🔍 Security scan completed',
        '💰 Asset tracking updated',
        '📊 Market analysis ready',
        '🚨 New threat detected',
        '✅ Wallet security verified',
        '📈 Price alert triggered',
        '🔐 Security report generated'
    ];
    
    const randomActivity = activities[Math.floor(Math.random() * activities.length)];
    
    // Create notification
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: -300px;
        background: rgba(79, 209, 199, 0.9);
        color: #0a0e27;
        padding: 1rem;
        border-radius: 10px;
        z-index: 10001;
        transition: right 0.5s ease;
        font-weight: 600;
        max-width: 250px;
    `;
    notification.textContent = randomActivity;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.right = '20px';
    }, 100);
    
    // Animate out
    setTimeout(() => {
        notification.style.right = '-300px';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 500);
    }, 3000);
}

// Start bot activity simulation
setInterval(simulateBotActivity, 15000);

// Stats counter animation with bot-specific numbers
const animateCounters = () => {
    const counters = document.querySelectorAll('.stat-number');
    
    counters.forEach(counter => {
        const target = counter.textContent;
        let numericTarget;
        let suffix = '';
        
        if (target.includes('24/7')) {
            // Skip animation for 24/7
            return;
        } else if (target.includes('K+')) {
            numericTarget = parseInt(target) * 1000;
            suffix = 'K+';
        } else {
            numericTarget = parseInt(target);
        }
        
        let current = 0;
        const increment = numericTarget / (suffix ? 100 : 50);
        const timer = setInterval(() => {
            current += increment;
            if (current >= numericTarget) {
                current = numericTarget;
                clearInterval(timer);
            }
            
            if (suffix === 'K+') {
                counter.textContent = Math.floor(current / 1000) + 'K+';
            } else {
                counter.textContent = Math.floor(current);
            }
        }, 30);
    });
};

// Trigger counter animation when stats section is visible
const statsSection = document.querySelector('.stats');
const statsObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            animateCounters();
            statsObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.5 });

if (statsSection) {
    statsObserver.observe(statsSection);
}

// Add typing effect to hero title
function typeEffect() {
    const title = document.querySelector('.hero-title');
    const text = 'Automated Telegram Bots for Cybersecurity & Finance';
    const highlightText = 'Telegram Bots';
    
    if (title) {
        title.innerHTML = '';
        let i = 0;
        
        function typeChar() {
            if (i < text.length) {
                if (text.substr(i, highlightText.length) === highlightText) {
                    title.innerHTML += `<span class="highlight">${highlightText}</span>`;
                    i += highlightText.length;
                } else {
                    title.innerHTML += text[i];
                    i++;
                }
                setTimeout(typeChar, 50);
            }
        }
        
        typeChar();
    }
}

// Initialize typing effect when page loads
window.addEventListener('load', typeEffect);

// Add parallax effect to hero background
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const hero = document.querySelector('.hero');
    if (hero && scrolled < hero.offsetHeight) {
        hero.style.transform = `translateY(${scrolled * 0.3}px)`;
    }
});

// Service card interaction effects
document.querySelectorAll('.service-card').forEach(card => {
    card.addEventListener('mouseenter', () => {
        const icon = card.querySelector('.service-icon');
        icon.style.transform = 'scale(1.2) rotate(5deg)';
        icon.style.transition = 'transform 0.3s ease';
    });
    
    card.addEventListener('mouseleave', () => {
        const icon = card.querySelector('.service-icon');
        icon.style.transform = 'scale(1) rotate(0deg)';
    });
});
